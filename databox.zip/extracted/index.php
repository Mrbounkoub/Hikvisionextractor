<?php
// Define the path to the folder whose contents we want to display
$folder_path = '../uploads';

// Get the contents of the folder
$folder_contents = scandir($folder_path);

// Remove the "." and ".." entries
$folder_contents = array_diff($folder_contents, array('..', '.'));

// Output the contents as an unordered list
echo '<ul>';
foreach ($folder_contents as $file) {
    echo '<li>' . $file . '</li>';
}
echo '</ul>';
?>

